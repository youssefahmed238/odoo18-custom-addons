{
    'name': 'Tax Split Lines',
    'version': '1.0',
    'depends': ['account'],
    'installable': True,
    'application': False,
}
